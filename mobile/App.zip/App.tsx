import React, { useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as DocumentPicker from "expo-document-picker";

/*
 * ============================================================
 * API CONFIGURATION
 * ============================================================
 */

const PRODUCTION_API_URL =
  "https://apply-job-backend.vercel.app";

const LOCAL_NATIVE_API_URL =
  "http://localhost:8000";

const API_BASE_URL =
  Platform.OS === "web"
    ? PRODUCTION_API_URL
    : LOCAL_NATIVE_API_URL;

/*
 * ============================================================
 * TYPES
 * ============================================================
 */

type AuthMode =
  | "login"
  | "register"
  | "forgot"
  | "verify"
  | "reset";

type Tab =
  | "workspace"
  | "applications";

type ThemeMode =
  | "dark"
  | "light";

type Application = {
  id: number;
  job_id?: number;
  job_title?: string;
  company?: string;
  job_url?: string;
  match_score?: number;
  status?: string;
  cover_letter?: string;
  notes?: string;
  created_at?: string;
};

type JobAnalysis = {
  title?: string;
  company?: string;
  match_score?: number;
  score?: number;
  summary?: string;
  strengths?: string[];
  weaknesses?: string[];
  missing_skills?: string[];
  recommendations?: string[];
  [key: string]: any;
};

/*
 * ============================================================
 * APP
 * ============================================================
 */

export default function App() {
  /*
   * ----------------------------------------------------------
   * AUTH STATE
   * ----------------------------------------------------------
   */

  const [token, setToken] =
    useState<string | null>(null);

  const [initializing, setInitializing] =
    useState(true);

  const [authMode, setAuthMode] =
    useState<AuthMode>("login");

  const [email, setEmail] =
    useState("");

  const [password, setPassword] =
    useState("");

  const [verificationCode, setVerificationCode] =
    useState("");

  const [resetCode, setResetCode] =
    useState("");

  const [newPassword, setNewPassword] =
    useState("");

  const [resetCodeVerified, setResetCodeVerified] =
    useState(false);

  const [loading, setLoading] =
    useState(false);

  const [message, setMessage] =
    useState("");

  /*
   * ----------------------------------------------------------
   * DASHBOARD
   * ----------------------------------------------------------
   */

  const [activeTab, setActiveTab] =
    useState<Tab>("workspace");

  const [theme, setTheme] =
    useState<ThemeMode>("dark");

  /*
   * ----------------------------------------------------------
   * RESUME
   * ----------------------------------------------------------
   */

  const [resumeName, setResumeName] =
    useState("");

  const [resumeText, setResumeText] =
    useState("");

  /*
   * ----------------------------------------------------------
   * JOB
   * ----------------------------------------------------------
   */

  const [jobDescription, setJobDescription] =
    useState("");

  const [jobUrl, setJobUrl] =
    useState("");

  const [analysis, setAnalysis] =
    useState<JobAnalysis | null>(null);

  const [coverLetter, setCoverLetter] =
    useState("");

  /*
   * ----------------------------------------------------------
   * APPLICATIONS
   * ----------------------------------------------------------
   */

  const [applications, setApplications] =
    useState<Application[]>([]);

  const [selectedApplication, setSelectedApplication] =
    useState<Application | null>(null);

  /*
   * ----------------------------------------------------------
   * PASSWORD VISIBILITY
   * ----------------------------------------------------------
   */

  const [showPassword, setShowPassword] =
    useState(false);

  const [showNewPassword, setShowNewPassword] =
    useState(false);

  /*
   * ----------------------------------------------------------
   * PROFILE
   * ----------------------------------------------------------
   */

  const [profileName, setProfileName] =
    useState("");

  const [profilePhone, setProfilePhone] =
    useState("");

  const [profileEmail, setProfileEmail] =
    useState("");

  const [profileLinkedIn, setProfileLinkedIn] =
    useState("");

  const [profileAddress, setProfileAddress] =
    useState("");

  /*
   * ==========================================================
   * COLORS
   * ==========================================================
   */

  const colors = useMemo(() => {
    if (theme === "dark") {
      return {
        background: "#080C14",
        surface: "#101722",
        surface2: "#151E2D",
        surface3: "#1A2535",
        primary: "#6366F1",
        primaryDark: "#4F46E5",
        primarySoft: "#202554",
        text: "#F8FAFC",
        textSecondary: "#94A3B8",
        textMuted: "#64748B",
        border: "#243044",
        success: "#22C55E",
        danger: "#EF4444",
        warning: "#F59E0B",
        input: "#0D1420",
        white: "#FFFFFF",
      };
    }

    return {
      background: "#F6F8FC",
      surface: "#FFFFFF",
      surface2: "#F1F5F9",
      surface3: "#E8EEF7",
      primary: "#4F46E5",
      primaryDark: "#4338CA",
      primarySoft: "#EEF2FF",
      text: "#0F172A",
      textSecondary: "#64748B",
      textMuted: "#94A3B8",
      border: "#E2E8F0",
      success: "#16A34A",
      danger: "#DC2626",
      warning: "#D97706",
      input: "#FFFFFF",
      white: "#FFFFFF",
    };
  }, [theme]);

  /*
   * ==========================================================
   * INITIALIZATION
   * ==========================================================
   */

  useEffect(() => {
    initializeApp();
  }, []);

  async function initializeApp() {
    try {
      const [
        savedToken,
        savedTheme,
        savedProfile,
      ] = await Promise.all([
        AsyncStorage.getItem(
          "applyai_token"
        ),

        AsyncStorage.getItem(
          "applyai_theme"
        ),

        AsyncStorage.getItem(
          "applyai_profile"
        ),
      ]);

      if (
        savedTheme === "dark" ||
        savedTheme === "light"
      ) {
        setTheme(savedTheme);
      }

      if (savedProfile) {
        try {
          const parsedProfile =
            JSON.parse(savedProfile);

          setProfileName(
            parsedProfile?.name || ""
          );

          setProfilePhone(
            parsedProfile?.phone || ""
          );

          setProfileEmail(
            parsedProfile?.email || ""
          );

          setProfileLinkedIn(
            parsedProfile?.linkedin || ""
          );

          setProfileAddress(
            parsedProfile?.address || ""
          );
        } catch (profileError) {
          console.log(
            "Profile parse error:",
            profileError
          );
        }
      }

      if (savedToken) {
        setToken(savedToken);
        setActiveTab("workspace");
      }
    } catch (error) {
      console.log(
        "Initialization error:",
        error
      );
    } finally {
      setInitializing(false);
    }
  }

  /*
   * ==========================================================
   * PROFILE
   * ==========================================================
   */

  async function saveProfile(next: {
    name?: string;
    phone?: string;
    email?: string;
    linkedin?: string;
    address?: string;
  }) {
    const merged = {
      name:
        next.name ?? profileName,

      phone:
        next.phone ?? profilePhone,

      email:
        next.email ?? profileEmail,

      linkedin:
        next.linkedin ?? profileLinkedIn,

      address:
        next.address ?? profileAddress,
    };

    try {
      await AsyncStorage.setItem(
        "applyai_profile",
        JSON.stringify(merged)
      );
    } catch (error) {
      console.log(
        "Profile save error:",
        error
      );
    }
  }

  /*
   * ==========================================================
   * COVER LETTER PLACEHOLDER CLEANUP
   * ==========================================================
   */

  function fillCoverLetterPlaceholders(
    letter: string
  ) {
    if (!letter) {
      return letter;
    }

    let result = letter;

    const bracketReplacements: [
      RegExp,
      string
    ][] = [
      [
        /\[\s*Your Name\s*\]/gi,
        profileName,
      ],

      [
        /\[\s*Your Address\s*\]/gi,
        profileAddress,
      ],

      [
        /\[\s*Phone\s*\]/gi,
        profilePhone,
      ],

      [
        /\[\s*Your Phone\s*\]/gi,
        profilePhone,
      ],

      [
        /\[\s*Email\s*\]/gi,
        profileEmail,
      ],

      [
        /\[\s*Your Email\s*\]/gi,
        profileEmail,
      ],

      [
        /\[\s*LinkedIn\s*\]/gi,
        profileLinkedIn,
      ],
    ];

    bracketReplacements.forEach(
      ([pattern, value]) => {
        if (value) {
          result =
            result.replace(
              pattern,
              value
            );
        }
      }
    );

    const dash =
      "[\\s.\\-\\u2010\\u2011\\u2012\\u2013\\u2014]{0,2}";

    const fakePhonePattern =
      new RegExp(
        `\\+?\\d{0,3}${dash}x{2,3}${dash}x{6,8}`,
        "gi"
      );

    result = result.replace(
      fakePhonePattern,
      profilePhone || ""
    );

    result = result.replace(
      /linkedin\.com\/in\/(yourprofile|yourname|your-name)/gi,
      profileLinkedIn || ""
    );

    result = result.replace(
      /your\.?email@example\.com/gi,
      profileEmail || ""
    );

    result = result.replace(
      /\[\s*[^\]\n]*\s*\]/g,
      ""
    );

    result = result.replace(
      /\*{2,}\s*\*{2,}/g,
      ""
    );

    result = result.replace(
      /^\s*\*{2,}\s*$/gm,
      ""
    );

    result = result.replace(
      /[ \t]*\|[ \t]*\|[ \t]*/g,
      " | "
    );

    result = result.replace(
      /^[ \t]*\|[ \t]*/gm,
      ""
    );

    result = result.replace(
      /[ \t]*\|[ \t]*$/gm,
      ""
    );

    result = result.replace(
      /[ \t]+\n/g,
      "\n"
    );

    result = result.replace(
      /\n{3,}/g,
      "\n\n"
    );

    return result.trim();
  }

  /*
   * ==========================================================
   * RESUME PROFILE EXTRACTION
   * ==========================================================
   */

  function extractProfileFromResume(
    text: string
  ) {
    if (!text || !text.trim()) {
      return {
        name: "",
        phone: "",
        email: "",
        linkedin: "",
        address: "",
      };
    }

    const emailMatch =
      text.match(
        /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/
      );

    const linkedinMatch =
      text.match(
        /(?:https?:\/\/)?(?:www\.)?linkedin\.com\/in\/[a-zA-Z0-9\-_%]+/i
      );

    const phoneCandidates =
      Array.from(
        text.matchAll(
          /(\+?\d[\d\s().-]{6,17}\d)/g
        )
      );

    const validPhone =
      phoneCandidates
        .map((match) =>
          match[1].trim()
        )
        .find((candidate) => {
          const digitsOnly =
            candidate.replace(
              /\D/g,
              ""
            );

          return (
            digitsOnly.length >= 9 &&
            digitsOnly.length <= 14
          );
        });

    const lines =
      text
        .split(/\r?\n/)
        .map((line) =>
          line.trim()
        )
        .filter(
          (line) =>
            line.length > 0
        )
        .slice(0, 8);

    const skipWords =
      /resume|curriculum|vitae|^cv$|objective|summary|profile|experience|education|skills|projects|contact|technical|certification|reference|language|achievement|award|publication|interest|hobbies|declaration|core|proficienc/i;

    const nameLine =
      lines.find((line) => {
        if (line.includes("@")) {
          return false;
        }

        if (/\d/.test(line)) {
          return false;
        }

        if (
          line.length < 3 ||
          line.length > 45
        ) {
          return false;
        }

        if (
          line === line.toUpperCase()
        ) {
          return false;
        }

        const words =
          line.split(/\s+/);

        if (
          words.length < 2 ||
          words.length > 4
        ) {
          return false;
        }

        const looksLikeName =
          words.every(
            (word) =>
              /^[A-Z][a-zA-Z.'-]*$/.test(
                word
              )
          );

        return (
          looksLikeName &&
          !skipWords.test(line)
        );
      });

    return {
      name:
        nameLine || "",

      phone:
        validPhone || "",

      email:
        emailMatch
          ? emailMatch[0]
          : "",

      linkedin:
        linkedinMatch
          ? linkedinMatch[0]
          : "",

      address: "",
    };
  }

  /*
   * ==========================================================
   * COVER LETTER DISPLAY
   * ==========================================================
   */

  function formatCoverLetterForDisplay(
    letter: string
  ) {
    if (!letter) {
      return letter;
    }

    let result = letter;

    result =
      result.replace(
        /\*\*(.+?)\*\*/g,
        "$1"
      );

    result =
      result.replace(
        /(^|\s)\*(\S.*?\S|\S)\*(?=\s|$)/g,
        "$1$2"
      );

    result =
      result.replace(
        /^[ \t]*[*-][ \t]+/gm,
        "• "
      );

    result =
      result.replace(
        /^[ \t]+•/gm,
        "  •"
      );

    result =
      result.replace(
        /\*+/g,
        ""
      );

    result =
      result.replace(
        /\n{3,}/g,
        "\n\n"
      );

    return result.trim();
  }

  /*
   * ==========================================================
   * BUILD RESUME TEXT FOR COVER LETTER
   * ==========================================================
   */

  function buildResumeTextForCoverLetter() {
    const contactLines: string[] = [];

    if (profileName) {
      contactLines.push(
        `Name: ${profileName}`
      );
    }

    if (profilePhone) {
      contactLines.push(
        `Phone: ${profilePhone}`
      );
    }

    if (profileEmail) {
      contactLines.push(
        `Email: ${profileEmail}`
      );
    }

    if (profileLinkedIn) {
      contactLines.push(
        `LinkedIn: ${profileLinkedIn}`
      );
    }

    if (profileAddress) {
      contactLines.push(
        `Address: ${profileAddress}`
      );
    }

    if (contactLines.length === 0) {
      return resumeText;
    }

    return `CONTACT INFORMATION
${contactLines.join("\n")}

${resumeText}`;
  }

  /*
   * ==========================================================
   * FINAL COVER LETTER
   * ==========================================================
   */

  function buildFinalCoverLetter(
    rawLetter: string
  ) {
    const fallbackProfile =
      extractProfileFromResume(
        resumeText
      );

    const effectiveName =
      profileName ||
      fallbackProfile.name;

    const effectivePhone =
      profilePhone ||
      fallbackProfile.phone;

    const effectiveEmail =
      profileEmail ||
      fallbackProfile.email;

    const effectiveLinkedIn =
      profileLinkedIn ||
      fallbackProfile.linkedin;

    const effectiveAddress =
      profileAddress ||
      fallbackProfile.address;

    const cleaned =
      formatCoverLetterForDisplay(
        fillCoverLetterPlaceholders(
          rawLetter
        )
      );

    const lines =
      cleaned
        .split(/\n/)
        .map((line) =>
          line.trim()
        );

    const dearIndex =
      lines.findIndex((line) =>
        /^dear\s/i.test(line)
      );

    let bodyLines =
      dearIndex >= 0
        ? lines.slice(dearIndex)
        : lines;

    if (dearIndex === -1) {
      const salutation =
        analysis?.company
          ? `Dear ${analysis.company} Hiring Team,`
          : "Dear Hiring Manager,";

      bodyLines = [
        salutation,
        "",
        ...bodyLines,
      ];
    }

    const closingPattern =
      /^(sincerely|best regards|kind regards|regards|yours\s+(faithfully|sincerely|truly)|respectfully|warm regards|thank you for your consideration)[,.]?$/i;

    const closingIndex =
      bodyLines
        .map(
          (
            line,
            index
          ) => ({
            line,
            index,
          })
        )
        .reverse()
        .find(
          ({
            line,
          }) =>
            closingPattern.test(
              line.trim()
            )
        )?.index;

    if (
      closingIndex !== undefined
    ) {
      bodyLines =
        bodyLines.slice(
          0,
          closingIndex
        );
    } else {
      const lastLine =
        bodyLines[
          bodyLines.length - 1
        ];

      const looksLikeDanglingName =
        !!lastLine &&
        effectiveName &&
        lastLine.trim() ===
          effectiveName.trim();

      if (
        looksLikeDanglingName
      ) {
        bodyLines =
          bodyLines.slice(
            0,
            -1
          );
      }
    }

    while (
      bodyLines.length &&
      bodyLines[
        bodyLines.length - 1
      ].trim() === ""
    ) {
      bodyLines =
        bodyLines.slice(
          0,
          -1
        );
    }

    const senderLines: string[] =
      [];

    if (effectiveName) {
      senderLines.push(
        effectiveName
      );
    }

    if (effectiveAddress) {
      senderLines.push(
        effectiveAddress
      );
    }

    const senderContactBits: string[] =
      [];

    if (effectivePhone) {
      senderContactBits.push(
        effectivePhone
      );
    }

    if (effectiveEmail) {
      senderContactBits.push(
        effectiveEmail
      );
    }

    if (effectiveLinkedIn) {
      senderContactBits.push(
        effectiveLinkedIn
      );
    }

    if (
      senderContactBits.length
    ) {
      senderLines.push(
        senderContactBits.join(
          " | "
        )
      );
    }

    const today =
      new Date().toLocaleDateString(
        "en-GB",
        {
          day: "numeric",
          month: "long",
          year: "numeric",
        }
      );

    senderLines.push(today);

    const recipientLines: string[] =
      [];

    if (analysis?.company) {
      recipientLines.push(
        "Hiring Manager"
      );

      recipientLines.push(
        analysis.company
      );
    }

    const closingLines = [
      "Sincerely,",
      "",
      effectiveName || "",
    ].filter(
      (
        line,
        index,
        arr
      ) =>
        !(
          index ===
            arr.length - 1 &&
          line === "" &&
          !effectiveName
        )
    );

    if (
      (!profileName &&
        effectiveName) ||
      (!profilePhone &&
        effectivePhone) ||
      (!profileEmail &&
        effectiveEmail) ||
      (!profileLinkedIn &&
        effectiveLinkedIn)
    ) {
      setProfileName(
        effectiveName
      );

      setProfilePhone(
        effectivePhone
      );

      setProfileEmail(
        effectiveEmail
      );

      setProfileLinkedIn(
        effectiveLinkedIn
      );

      setProfileAddress(
        effectiveAddress
      );

      saveProfile({
        name: effectiveName,
        phone: effectivePhone,
        email: effectiveEmail,
        linkedin:
          effectiveLinkedIn,
        address:
          effectiveAddress,
      });
    }

    const sections = [
      senderLines.join("\n"),

      recipientLines.length
        ? recipientLines.join("\n")
        : "",

      bodyLines
        .join("\n")
        .trim(),

      closingLines.join("\n"),
    ].filter(
      (section) =>
        section.trim().length > 0
    );

    return sections
      .join("\n\n")
      .trim();
  }

  /*
   * ==========================================================
   * THEME
   * ==========================================================
   */

  async function toggleTheme() {
    const nextTheme =
      theme === "dark"
        ? "light"
        : "dark";

    setTheme(nextTheme);

    try {
      await AsyncStorage.setItem(
        "applyai_theme",
        nextTheme
      );
    } catch (error) {
      console.log(
        "Theme save error:",
        error
      );
    }
  }

  /*
   * ==========================================================
   * ERRORS
   * ==========================================================
   */

  function showError(error: any) {
    const detail =
      error?.message ||
      "Something went wrong. Please try again.";

    setMessage(detail);

    if (
      Platform.OS !== "web"
    ) {
      Alert.alert(
        "ApplyAI",
        detail
      );
    }
  }

  /*
   * ==========================================================
   * API
   * ==========================================================
   */

  async function apiRequest(
    endpoint: string,
    options: RequestInit = {}
  ) {
    const response =
      await fetch(
        `${API_BASE_URL}${endpoint}`,
        {
          ...options,

          headers: {
            "Content-Type":
              "application/json",

            ...(options.headers || {}),
          },
        }
      );

    const text =
      await response.text();

    let data: any = {};

    try {
      data = text
        ? JSON.parse(text)
        : {};
    } catch {
      data = {
        detail:
          text ||
          "Unexpected server response",
      };
    }

    if (!response.ok) {
      throw new Error(
        data?.detail ||
          data?.message ||
          `Request failed (${response.status})`
      );
    }

    return data;
  }

  async function apiAuth(
    endpoint: string,
    options: RequestInit = {}
  ) {
    if (!token) {
      throw new Error(
        "You are not signed in."
      );
    }

    return apiRequest(
      endpoint,
      {
        ...options,

        headers: {
          ...(options.headers || {}),

          Authorization:
            `Bearer ${token}`,
        },
      }
    );
  }

  /*
   * ==========================================================
   * AUTH
   * ==========================================================
   */

  async function saveToken(
    accessToken: string
  ) {
    await AsyncStorage.setItem(
      "applyai_token",
      accessToken
    );

    setToken(accessToken);
    setActiveTab("workspace");
    setSelectedApplication(null);
  }

  function validateEmail() {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(
      email.trim()
    );
  }

  async function loginUser() {
    if (!validateEmail()) {
      setMessage(
        "Please enter a valid email address."
      );

      return;
    }

    if (!password) {
      setMessage(
        "Please enter your password."
      );

      return;
    }

    setLoading(true);
    setMessage("");

    try {
      const response =
        await apiRequest(
          "/api/auth/login",
          {
            method: "POST",

            body: JSON.stringify({
              email:
                email
                  .trim()
                  .toLowerCase(),

              password,
            }),
          }
        );

      if (
        response?.access_token
      ) {
        await saveToken(
          response.access_token
        );

        setPassword("");
        setVerificationCode("");
        setMessage("");

        await loadApplicationsWithToken(
          response.access_token
        );
      } else {
        throw new Error(
          "Login succeeded but no access token was returned."
        );
      }
    } catch (error: any) {
      if (
        error?.message
          ?.toLowerCase()
          .includes(
            "verify your email"
          )
      ) {
        setAuthMode("verify");

        setMessage(
          "Please verify your email to continue."
        );
      } else {
        showError(error);
      }
    } finally {
      setLoading(false);
    }
  }

  async function registerUser() {
    if (!validateEmail()) {
      setMessage(
        "Please enter a valid email address."
      );

      return;
    }

    if (
      password.length < 8
    ) {
      setMessage(
        "Password must be at least 8 characters."
      );

      return;
    }

    setLoading(true);
    setMessage("");

    try {
      await apiRequest(
        "/api/auth/register",
        {
          method: "POST",

          body: JSON.stringify({
            email:
              email
                .trim()
                .toLowerCase(),

            password,
          }),
        }
      );

      setVerificationCode("");
      setAuthMode("verify");

      setMessage(
        "Account created. Check your email for the verification code."
      );

      if (
        Platform.OS !== "web"
      ) {
        Alert.alert(
          "Verify your email",
          "We sent a verification code to your email address."
        );
      }
    } catch (error: any) {
      showError(error);
    } finally {
      setLoading(false);
    }
  }

  async function resendVerificationCode() {
    if (!validateEmail()) {
      setMessage(
        "Enter your email first."
      );

      return;
    }

    setLoading(true);
    setMessage("");

    try {
      await apiRequest(
        "/api/auth/send-verification",
        {
          method: "POST",

          body: JSON.stringify({
            email:
              email
                .trim()
                .toLowerCase(),
          }),
        }
      );

      setMessage(
        "A new verification code has been sent to your email."
      );
    } catch (error: any) {
      showError(error);
    } finally {
      setLoading(false);
    }
  }

  async function verifyEmail() {
    if (!validateEmail()) {
      setMessage(
        "Please enter a valid email."
      );

      return;
    }

    if (
      !verificationCode.trim()
    ) {
      setMessage(
        "Please enter the verification code."
      );

      return;
    }

    setLoading(true);
    setMessage("");

    try {
      await apiRequest(
        "/api/auth/verify-email",
        {
          method: "POST",

          body: JSON.stringify({
            email:
              email
                .trim()
                .toLowerCase(),

            code:
              verificationCode.trim(),
          }),
        }
      );

      if (!password) {
        setAuthMode("login");
        setVerificationCode("");

        setMessage(
          "Email verified successfully. Please sign in."
        );

        return;
      }

      const loginResponse =
        await apiRequest(
          "/api/auth/login",
          {
            method: "POST",

            body: JSON.stringify({
              email:
                email
                  .trim()
                  .toLowerCase(),

              password,
            }),
          }
        );

      if (
        !loginResponse?.access_token
      ) {
        throw new Error(
          "Verification succeeded, but automatic login failed."
        );
      }

      await saveToken(
        loginResponse.access_token
      );

      setVerificationCode("");
      setPassword("");
      setMessage("");

      await loadApplicationsWithToken(
        loginResponse.access_token
      );

      if (
        Platform.OS !== "web"
      ) {
        setTimeout(() => {
          Alert.alert(
            "Welcome to ApplyAI",
            "Your email has been verified successfully."
          );
        }, 250);
      }
    } catch (error: any) {
      showError(error);
    } finally {
      setLoading(false);
    }
  }

  async function requestPasswordReset() {
    if (!validateEmail()) {
      setMessage(
        "Please enter a valid email."
      );

      return;
    }

    setLoading(true);
    setMessage("");
    setResetCodeVerified(false);

    try {
      await apiRequest(
        "/api/auth/forgot-password",
        {
          method: "POST",

          body: JSON.stringify({
            email:
              email
                .trim()
                .toLowerCase(),
          }),
        }
      );

      setResetCode("");
      setAuthMode("reset");

      setMessage(
        "Password reset code sent to your email."
      );
    } catch (error: any) {
      showError(error);
    } finally {
      setLoading(false);
    }
  }

  async function verifyResetCode() {
    if (
      !resetCode.trim()
    ) {
      setMessage(
        "Please enter the reset code."
      );

      return;
    }

    setLoading(true);
    setMessage("");

    try {
      await apiRequest(
        "/api/auth/verify-reset-code",
        {
          method: "POST",

          body: JSON.stringify({
            email:
              email
                .trim()
                .toLowerCase(),

            code:
              resetCode.trim(),
          }),
        }
      );

      setResetCodeVerified(
        true
      );

      setMessage(
        "Code verified. You can now create a new password."
      );
    } catch (error: any) {
      setResetCodeVerified(
        false
      );

      showError(error);
    } finally {
      setLoading(false);
    }
  }

  async function resetPassword() {
    if (!resetCodeVerified) {
      setMessage(
        "Please verify your reset code first."
      );

      return;
    }

    if (
      newPassword.length < 8
    ) {
      setMessage(
        "New password must be at least 8 characters."
      );

      return;
    }

    setLoading(true);
    setMessage("");

    try {
      await apiRequest(
        "/api/auth/reset-password",
        {
          method: "POST",

          body: JSON.stringify({
            email:
              email
                .trim()
                .toLowerCase(),

            code:
              resetCode.trim(),

            new_password:
              newPassword,
          }),
        }
      );

      setPassword("");
      setNewPassword("");
      setResetCode("");
      setResetCodeVerified(
        false
      );
      setAuthMode("login");

      setMessage(
        "Password updated successfully. Please sign in."
      );
    } catch (error: any) {
      showError(error);
    } finally {
      setLoading(false);
    }
  }

  async function logout() {
    await AsyncStorage.removeItem(
      "applyai_token"
    );

    setToken(null);
    setApplications([]);
    setAnalysis(null);
    setCoverLetter("");
    setResumeName("");
    setResumeText("");
    setSelectedApplication(null);
    setActiveTab("workspace");

    setAuthMode("login");
    setPassword("");
    setVerificationCode("");
    setResetCode("");
    setNewPassword("");
  }

  /*
   * ==========================================================
   * RESUME RESPONSE EXTRACTION
   * ==========================================================
   */

  function extractTextFromResponse(
    data: any
  ): string {
    const candidates = [
      data?.text,

      data?.resume_text,

      data?.resumeText,

      data?.content,

      data?.extracted_text,

      data?.parsed_text,

      data?.raw_text,

      data?.body,

      data?.resume?.text,

      data?.resume?.content,

      data?.resume?.resume_text,

      data?.resume?.raw_text,

      data?.data?.text,

      data?.data?.resume_text,

      data?.data?.content,

      data?.result?.text,

      data?.result?.resume_text,

      Array.isArray(data)
        ? data[0]?.text ||
          data[0]?.resume_text ||
          data[0]?.content
        : undefined,
    ];

    return (
      candidates.find(
        (candidate) =>
          typeof candidate ===
            "string" &&
          candidate
            .trim()
            .length > 0
      ) || ""
    );
  }

  /*
   * ==========================================================
   * FETCH RESUME TEXT FROM SERVER
   * ==========================================================
   */

  async function fetchResumeTextFromServer(): Promise<string> {
    const candidateEndpoints = [
      "/api/resume",
      "/api/resume/me",
      "/api/resume/text",
      "/api/resume/latest",
      "/api/user/resume",
      "/api/resumes/latest",
    ];

    for (
      const endpoint of candidateEndpoints
    ) {
      try {
        const response =
          await apiAuth(endpoint);

        const text =
          extractTextFromResponse(
            response
          );

        if (text) {
          return text;
        }
      } catch {
        /*
         * Try next endpoint.
         */
      }
    }

    return "";
  }

  /*
   * ==========================================================
   * REFRESH RESUME TEXT
   * ==========================================================
   */

  async function refreshResumeTextFromServer() {
    if (!token) {
      return;
    }

    setLoading(true);
    setMessage("");

    try {
      const text =
        await fetchResumeTextFromServer();

      if (text) {
        setResumeText(text);

        const detectedProfile =
          extractProfileFromResume(
            text
          );

        if (
          detectedProfile.name
        ) {
          setProfileName(
            detectedProfile.name
          );
        }

        if (
          detectedProfile.phone
        ) {
          setProfilePhone(
            detectedProfile.phone
          );
        }

        if (
          detectedProfile.email
        ) {
          setProfileEmail(
            detectedProfile.email
          );
        }

        if (
          detectedProfile.linkedin
        ) {
          setProfileLinkedIn(
            detectedProfile.linkedin
          );
        }

        await saveProfile({
          name:
            detectedProfile.name ||
            profileName,

          phone:
            detectedProfile.phone ||
            profilePhone,

          email:
            detectedProfile.email ||
            profileEmail,

          linkedin:
            detectedProfile.linkedin ||
            profileLinkedIn,

          address:
            profileAddress,
        });

        setMessage(
          "Full resume text refreshed successfully."
        );
      } else {
        setMessage(
          "Couldn't find your resume text on the server. Check your backend resume endpoint."
        );
      }
    } catch (error: any) {
      showError(error);
    } finally {
      setLoading(false);
    }
  }

  /*
   * ==========================================================
   * UPLOAD RESUME
   * ==========================================================
   */

  async function pickResume() {
    try {
      const result =
        await DocumentPicker.getDocumentAsync(
          {
            type: [
              "application/pdf",

              "application/msword",

              "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            ],

            copyToCacheDirectory:
              true,

            multiple: false,
          }
        );

      if (result.canceled) {
        return;
      }

      const file =
        result.assets?.[0];

      if (!file) {
        setMessage(
          "No file selected."
        );

        return;
      }

      setLoading(true);
      setMessage("");

      const formData =
        new FormData();

      /*
       * WEB
       */

      if (
        Platform.OS === "web"
      ) {
        if (!file.file) {
          throw new Error(
            "Browser file data is unavailable. Please select the resume again."
          );
        }

        formData.append(
          "file",
          file.file
        );
      } else {
        /*
         * ANDROID / IOS
         */

        formData.append(
          "file",
          {
            uri: file.uri,

            name:
              file.name ||
              "resume.pdf",

            type:
              file.mimeType ||
              "application/pdf",
          } as any
        );
      }

      const response =
        await fetch(
          `${API_BASE_URL}/api/resume/upload`,
          {
            method: "POST",

            headers: {
              Authorization:
                `Bearer ${token}`,
            },

            body: formData,
          }
        );

      const responseText =
        await response.text();

      let data: any = {};

      try {
        data =
          responseText
            ? JSON.parse(
                responseText
              )
            : {};
      } catch {
        data = {
          detail:
            responseText ||
            "Unexpected server response",
        };
      }

      if (!response.ok) {
        console.log(
          "RESUME UPLOAD STATUS:",
          response.status
        );

        console.log(
          "RESUME UPLOAD RESPONSE:",
          data
        );

        throw new Error(
          data?.detail ||
            data?.message ||
            `Resume upload failed (${response.status})`
        );
      }

      /*
       * Save filename
       */

      setResumeName(
        data?.filename ||
          data?.name ||
          file.name ||
          "Resume uploaded"
      );

      /*
       * --------------------------------------------------------
       * IMPORTANT:
       * First try to get extracted text from upload response.
       * --------------------------------------------------------
       */

      let extractedText =
        extractTextFromResponse(
          data
        );

      /*
       * --------------------------------------------------------
       * If upload response doesn't contain text,
       * try server endpoints.
       * --------------------------------------------------------
       */

      if (!extractedText) {
        extractedText =
          await fetchResumeTextFromServer();
      }

      /*
       * --------------------------------------------------------
       * SAVE FULL RESUME TEXT
       * --------------------------------------------------------
       */

      setResumeText(
        extractedText
      );

      /*
       * --------------------------------------------------------
       * AUTO DETECT PROFILE
       * --------------------------------------------------------
       */

      const detectedProfile =
        extractProfileFromResume(
          extractedText
        );

      if (
        detectedProfile.name
      ) {
        setProfileName(
          detectedProfile.name
        );
      }

      if (
        detectedProfile.phone
      ) {
        setProfilePhone(
          detectedProfile.phone
        );
      }

      if (
        detectedProfile.email
      ) {
        setProfileEmail(
          detectedProfile.email
        );
      }

      if (
        detectedProfile.linkedin
      ) {
        setProfileLinkedIn(
          detectedProfile.linkedin
        );
      }

      setProfileAddress(
        detectedProfile.address
      );

      await saveProfile({
        name:
          detectedProfile.name,

        phone:
          detectedProfile.phone,

        email:
          detectedProfile.email,

        linkedin:
          detectedProfile.linkedin,

        address:
          detectedProfile.address,
      });

      /*
       * --------------------------------------------------------
       * SUCCESS
       * --------------------------------------------------------
       */

      if (extractedText) {
        setMessage(
          "Resume uploaded successfully. Full resume text is now available below the upload button."
        );
      } else {
        console.log(
          "RESUME UPLOAD: no text field matched."
        );

        console.log(
          "RESPONSE KEYS:",
          Object.keys(
            data || {}
          )
        );

        setMessage(
          "Resume uploaded, but no readable text was returned. Use Refresh resume text or check your backend extraction endpoint."
        );
      }
    } catch (error: any) {
      console.log(
        "RESUME UPLOAD ERROR:",
        error
      );

      setMessage(
        error?.message ||
          "Resume upload failed."
      );
    } finally {
      setLoading(false);
    }
  }

  /*
   * ==========================================================
   * JOB ANALYSIS
   * ==========================================================
   */

  async function analyzeJob() {
    if (
      !jobDescription.trim()
    ) {
      setMessage(
        "Please paste the job description first."
      );

      return;
    }

    setLoading(true);
    setMessage("");
    setAnalysis(null);
    setCoverLetter("");

    try {
      const response =
        await fetch(
          `${API_BASE_URL}/api/jobs/analyze`,
          {
            method: "POST",

            headers: {
              "Content-Type":
                "application/json",

              Authorization:
                `Bearer ${token}`,
            },

            body: JSON.stringify({
              resume_text:
                resumeText || "",

              job_description:
                jobDescription || "",

              title: "",

              company: "",

              url: "",
            }),
          }
        );

      const responseText =
        await response.text();

      console.log(
        "ANALYZE STATUS:",
        response.status
      );

      console.log(
        "ANALYZE RESPONSE:",
        responseText
      );

      let data: any = {};

      try {
        data =
          responseText
            ? JSON.parse(
                responseText
              )
            : {};
      } catch {
        data = {
          detail:
            responseText,
        };
      }

      if (!response.ok) {
        throw new Error(
          typeof data?.detail ===
            "string"
            ? data.detail
            : JSON.stringify(
                data?.detail ||
                  data
              )
        );
      }

      setAnalysis(
        data?.analysis ||
          data?.data ||
          data
      );

      setMessage(
        "Job analysis completed successfully."
      );
    } catch (error: any) {
      showError(error);
    } finally {
      setLoading(false);
    }
  }

  /*
   * ==========================================================
   * COVER LETTER
   * ==========================================================
   */

  async function generateCoverLetter() {
    try {
      if (!token) {
        setMessage(
          "Please login first."
        );

        return;
      }

      if (!resumeText.trim()) {
        setMessage(
          "Please upload your resume first."
        );

        return;
      }

      if (
        !jobDescription.trim()
      ) {
        setMessage(
          "Please enter a job description first."
        );

        return;
      }

      setLoading(true);
      setMessage("");

      const response =
        await fetch(
          `${API_BASE_URL}/api/jobs/cover-letter`,
          {
            method: "POST",

            headers: {
              "Content-Type":
                "application/json",

              Authorization:
                `Bearer ${token}`,
            },

            body: JSON.stringify({
              resume_text:
                buildResumeTextForCoverLetter(),

              job_description:
                jobDescription,

              full_name:
                profileName,

              phone:
                profilePhone,

              email:
                profileEmail,

              linkedin:
                profileLinkedIn,

              address:
                profileAddress,
            }),
          }
        );

      const responseText =
        await response.text();

      console.log(
        "COVER LETTER STATUS:",
        response.status
      );

      console.log(
        "COVER LETTER RESPONSE:",
        responseText
      );

      let data: any = {};

      try {
        data =
          responseText
            ? JSON.parse(
                responseText
              )
            : {};
      } catch {
        data = {
          detail:
            responseText,
        };
      }

      if (!response.ok) {
        throw new Error(
          typeof data?.detail ===
            "string"
            ? data.detail
            : JSON.stringify(
                data?.detail ||
                  data
              )
        );
      }

      const generatedLetter =
        data?.cover_letter ||
        data?.coverLetter ||
        data?.letter ||
        data?.result ||
        data?.content ||
        "";

      const finalLetter =
        typeof generatedLetter ===
        "string"
          ? buildFinalCoverLetter(
              generatedLetter
            )
          : JSON.stringify(
              generatedLetter,
              null,
              2
            );

      setCoverLetter(
        finalLetter
      );

      setMessage(
        "Cover letter generated successfully."
      );
    } catch (error: any) {
      console.error(
        "COVER LETTER ERROR:",
        error
      );

      setMessage(
        error?.message ||
          "Failed to generate cover letter."
      );
    } finally {
      setLoading(false);
    }
  }

  /*
   * ==========================================================
   * SAVE APPLICATION
   * ==========================================================
   */

  async function saveApplication() {
    if (
      !jobDescription.trim()
    ) {
      setMessage(
        "Please analyze a job before saving it."
      );

      return;
    }

    setLoading(true);
    setMessage("");

    try {
      await apiAuth(
        "/api/applications",
        {
          method: "POST",

          body: JSON.stringify({
            job_title:
              analysis?.title ||
              "Job Application",

            company:
              analysis?.company ||
              "",

            job_url:
              jobUrl.trim(),

            match_score:
              analysis?.match_score ??
              analysis?.score ??
              0,

            status: "SAVED",

            cover_letter:
              coverLetter,

            notes: "",

            description:
              jobDescription.trim(),
          }),
        }
      );

      setMessage(
        "Application saved successfully."
      );

      await loadApplications();
    } catch (error: any) {
      showError(error);
    } finally {
      setLoading(false);
    }
  }

  /*
   * ==========================================================
   * APPLICATIONS
   * ==========================================================
   */

  async function loadApplicationsWithToken(
    accessToken: string
  ) {
    try {
      const response =
        await fetch(
          `${API_BASE_URL}/api/applications`,
          {
            headers: {
              Authorization:
                `Bearer ${accessToken}`,
            },
          }
        );

      if (!response.ok) {
        return;
      }

      const data =
        await response.json();

      const list =
        Array.isArray(data)
          ? data
          : data?.applications ||
            data?.items ||
            [];

      setApplications(list);
    } catch (error) {
      console.log(
        "Application loading error:",
        error
      );
    }
  }

  async function loadApplications() {
    if (!token) {
      return;
    }

    try {
      const response =
        await apiAuth(
          "/api/applications"
        );

      const list =
        Array.isArray(response)
          ? response
          : response?.applications ||
            response?.items ||
            [];

      setApplications(list);
    } catch (error) {
      console.log(
        "Application loading error:",
        error
      );
    }
  }

  useEffect(() => {
    if (token) {
      loadApplications();
    }
  }, [token]);

  /*
   * ==========================================================
   * UI HELPERS
   * ==========================================================
   */

  function clearMessage() {
    if (message) {
      setMessage("");
    }
  }

  function renderThemeButton() {
    return (
      <TouchableOpacity
        onPress={toggleTheme}
        activeOpacity={0.8}
        style={[
          styles.themeButton,
          {
            backgroundColor:
              colors.surface2,

            borderColor:
              colors.border,
          },
        ]}
      >
        <Text
          style={styles.themeIcon}
        >
          {theme === "dark"
            ? "☀️"
            : "🌙"}
        </Text>
      </TouchableOpacity>
    );
  }

  function renderBrandHeader(
    showLogout = false
  ) {
    return (
      <View
        style={[
          styles.header,
          {
            borderBottomColor:
              colors.border,
          },
        ]}
      >
        <View
          style={styles.brandRow}
        >
          <View
            style={[
              styles.logoSmall,
              {
                backgroundColor:
                  colors.primary,
              },
            ]}
          >
            <Text
              style={
                styles.logoText
              }
            >
              A
            </Text>
          </View>

          <View>
            <Text
              style={[
                styles.brandName,
                {
                  color:
                    colors.text,
                },
              ]}
            >
              ApplyAI
            </Text>

            <Text
              style={[
                styles.brandSubtitle,
                {
                  color:
                    colors.textSecondary,
                },
              ]}
            >
              AI Career Assistant
            </Text>
          </View>
        </View>

        <View
          style={
            styles.headerActions
          }
        >
          {renderThemeButton()}

          {showLogout && (
            <TouchableOpacity
              onPress={logout}
              activeOpacity={0.8}
              style={[
                styles.logoutButton,
                {
                  backgroundColor:
                    colors.surface2,

                  borderColor:
                    colors.border,
                },
              ]}
            >
              <Text
                style={{
                  fontSize: 16,
                }}
              >
                ↪
              </Text>
            </TouchableOpacity>
          )}
        </View>
      </View>
    );
  }

  function renderMessage() {
    if (!message) {
      return null;
    }

    return (
      <View
        style={[
          styles.messageBox,
          {
            backgroundColor:
              colors.primarySoft,

            borderColor:
              colors.primary,
          },
        ]}
      >
        <Text
          style={[
            styles.messageText,
            {
              color:
                colors.primary,
            },
          ]}
        >
          {message}
        </Text>
      </View>
    );
  }

  function renderInput(
    placeholder: string,
    value: string,
    onChangeText: (
      value: string
    ) => void,
    options?: {
      secure?: boolean;
      multiline?: boolean;
      keyboardType?: any;
      right?: React.ReactNode;
    }
  ) {
    return (
      <View
        style={[
          styles.inputWrapper,
          {
            backgroundColor:
              colors.input,

            borderColor:
              colors.border,
          },
        ]}
      >
        <TextInput
          placeholder={
            placeholder
          }

          placeholderTextColor={
            colors.textMuted
          }

          value={value}

          onChangeText={(value) => {
            onChangeText(value);
            clearMessage();
          }}

          secureTextEntry={
            options?.secure ||
            false
          }

          multiline={
            options?.multiline ||
            false
          }

          keyboardType={
            options?.keyboardType ||
            "default"
          }

          autoCapitalize="none"

          style={[
            styles.input,
            {
              color:
                colors.text,

              minHeight:
                options?.multiline
                  ? 130
                  : undefined,

              textAlignVertical:
                options?.multiline
                  ? "top"
                  : "center",
            },
          ]}
        />

        {options?.right}
      </View>
    );
  }

  function renderPrimaryButton(
    title: string,
    onPress: () => void,
    disabled = false
  ) {
    return (
      <TouchableOpacity
        onPress={onPress}
        disabled={
          disabled || loading
        }
        activeOpacity={0.85}
        style={[
          styles.primaryButton,
          {
            backgroundColor:
              colors.primary,

            opacity:
              disabled || loading
                ? 0.6
                : 1,
          },
        ]}
      >
        {loading ? (
          <ActivityIndicator
            color="#FFFFFF"
          />
        ) : (
          <Text
            style={
              styles.primaryButtonText
            }
          >
            {title}
          </Text>
        )}
      </TouchableOpacity>
    );
  }

  /*
   * ==========================================================
   * AUTH SCREEN
   * ==========================================================
   */

  function renderAuth() {
    let title =
      "Welcome back";

    let subtitle =
      "Sign in to continue your AI-powered job search.";

    if (
      authMode ===
      "register"
    ) {
      title =
        "Create your account";

      subtitle =
        "Build your AI-powered career workspace.";
    }

    if (
      authMode ===
      "forgot"
    ) {
      title =
        "Forgot password?";

      subtitle =
        "Enter your email and we'll send you a reset code.";
    }

    if (
      authMode ===
      "verify"
    ) {
      title =
        "Verify your email";

      subtitle =
        "Enter the verification code sent to your email.";
    }

    if (
      authMode ===
      "reset"
    ) {
      title =
        "Reset your password";

      subtitle =
        "Create a new secure password for your account.";
    }

    return (
      <SafeAreaView
        style={[
          styles.safe,
          {
            backgroundColor:
              colors.background,
          },
        ]}
      >
        <StatusBar
          barStyle={
            theme === "dark"
              ? "light-content"
              : "dark-content"
          }

          backgroundColor={
            colors.background
          }
        />

        {renderBrandHeader()}

        <KeyboardAvoidingView
          style={{
            flex: 1,
          }}
          behavior={
            Platform.OS ===
            "ios"
              ? "padding"
              : undefined
          }
        >
          <ScrollView
            contentContainerStyle={
              styles.authScroll
            }

            keyboardShouldPersistTaps="handled"

            showsVerticalScrollIndicator={
              true
            }

            persistentScrollbar={
              true
            }
          >
            <View
              style={[
                styles.authCard,
                {
                  backgroundColor:
                    colors.surface,

                  borderColor:
                    colors.border,
                },
              ]}
            >
              <View
                style={[
                  styles.heroIcon,
                  {
                    backgroundColor:
                      colors.primarySoft,
                  },
                ]}
              >
                <Text
                  style={
                    styles.heroIconText
                  }
                >
                  ✦
                </Text>
              </View>

              <Text
                style={[
                  styles.authTitle,
                  {
                    color:
                      colors.text,
                  },
                ]}
              >
                {title}
              </Text>

              <Text
                style={[
                  styles.authSubtitle,
                  {
                    color:
                      colors.textSecondary,
                  },
                ]}
              >
                {subtitle}
              </Text>

              {authMode !==
                "verify" &&
                authMode !==
                  "reset" && (
                  <>
                    <Text
                      style={[
                        styles.label,
                        {
                          color:
                            colors.text,
                        },
                      ]}
                    >
                      Email address
                    </Text>

                    {renderInput(
                      "you@example.com",
                      email,
                      setEmail,
                      {
                        keyboardType:
                          "email-address",
                      }
                    )}
                  </>
                )}

              {authMode ===
                "login" && (
                <>
                  <Text
                    style={[
                      styles.label,
                      {
                        color:
                          colors.text,
                      },
                    ]}
                  >
                    Password
                  </Text>

                  {renderInput(
                    "Enter your password",
                    password,
                    setPassword,
                    {
                      secure:
                        !showPassword,

                      right: (
                        <TouchableOpacity
                          onPress={() =>
                            setShowPassword(
                              !showPassword
                            )
                          }
                          style={
                            styles.eyeButton
                          }
                        >
                          <Text
                            style={{
                              color:
                                colors.textSecondary,
                            }}
                          >
                            {showPassword
                              ? "Hide"
                              : "Show"}
                          </Text>
                        </TouchableOpacity>
                      ),
                    }
                  )}

                  <TouchableOpacity
                    onPress={() => {
                      setAuthMode(
                        "forgot"
                      );

                      setMessage("");
                    }}
                    style={
                      styles.forgotButton
                    }
                  >
                    <Text
                      style={[
                        styles.linkText,
                        {
                          color:
                            colors.primary,
                        },
                      ]}
                    >
                      Forgot password?
                    </Text>
                  </TouchableOpacity>

                  {renderPrimaryButton(
                    "Sign in",
                    loginUser
                  )}

                  <View
                    style={
                      styles.dividerRow
                    }
                  >
                    <View
                      style={[
                        styles.divider,
                        {
                          backgroundColor:
                            colors.border,
                        },
                      ]}
                    />

                    <Text
                      style={[
                        styles.dividerText,
                        {
                          color:
                            colors.textMuted,
                        },
                      ]}
                    >
                      OR
                    </Text>

                    <View
                      style={[
                        styles.divider,
                        {
                          backgroundColor:
                            colors.border,
                        },
                      ]}
                    />
                  </View>

                  <TouchableOpacity
                    onPress={() => {
                      setAuthMode(
                        "register"
                      );

                      setMessage("");
                    }}
                    style={[
                      styles.secondaryButton,
                      {
                        borderColor:
                          colors.border,
                      },
                    ]}
                  >
                    <Text
                      style={[
                        styles.secondaryButtonText,
                        {
                          color:
                            colors.text,
                        },
                      ]}
                    >
                      Create an account
                    </Text>
                  </TouchableOpacity>
                </>
              )}

              {authMode ===
                "register" && (
                <>
                  <Text
                    style={[
                      styles.label,
                      {
                        color:
                          colors.text,
                      },
                    ]}
                  >
                    Password
                  </Text>

                  {renderInput(
                    "Minimum 8 characters",
                    password,
                    setPassword,
                    {
                      secure:
                        !showPassword,

                      right: (
                        <TouchableOpacity
                          onPress={() =>
                            setShowPassword(
                              !showPassword
                            )
                          }
                          style={
                            styles.eyeButton
                          }
                        >
                          <Text
                            style={{
                              color:
                                colors.textSecondary,
                            }}
                          >
                            {showPassword
                              ? "Hide"
                              : "Show"}
                          </Text>
                        </TouchableOpacity>
                      ),
                    }
                  )}

                  {renderPrimaryButton(
                    "Create account",
                    registerUser
                  )}

                  <TouchableOpacity
                    onPress={() => {
                      setAuthMode(
                        "login"
                      );

                      setMessage("");
                    }}
                    style={
                      styles.backButton
                    }
                  >
                    <Text
                      style={[
                        styles.linkText,
                        {
                          color:
                            colors.primary,
                        },
                      ]}
                    >
                      Already have an account? Sign in
                    </Text>
                  </TouchableOpacity>
                </>
              )}

              {authMode ===
                "forgot" && (
                <>
                  <Text
                    style={[
                      styles.label,
                      {
                        color:
                          colors.text,
                      },
                    ]}
                  >
                    Email address
                  </Text>

                  {renderInput(
                    "you@example.com",
                    email,
                    setEmail,
                    {
                      keyboardType:
                        "email-address",
                    }
                  )}

                  {renderPrimaryButton(
                    "Send reset code",
                    requestPasswordReset
                  )}

                  <TouchableOpacity
                    onPress={() => {
                      setAuthMode(
                        "login"
                      );

                      setMessage("");
                    }}
                    style={
                      styles.backButton
                    }
                  >
                    <Text
                      style={[
                        styles.linkText,
                        {
                          color:
                            colors.primary,
                        },
                      ]}
                    >
                      Back to sign in
                    </Text>
                  </TouchableOpacity>
                </>
              )}

              {authMode ===
                "verify" && (
                <>
                  <View
                    style={[
                      styles.emailBadge,
                      {
                        backgroundColor:
                          colors.surface2,

                        borderColor:
                          colors.border,
                      },
                    ]}
                  >
                    <Text
                      style={{
                        color:
                          colors.textSecondary,
                      }}
                    >
                      Verification email
                    </Text>

                    <Text
                      style={{
                        color:
                          colors.text,

                        fontWeight:
                          "700",

                        marginTop: 4,
                      }}
                    >
                      {email}
                    </Text>
                  </View>

                  <Text
                    style={[
                      styles.label,
                      {
                        color:
                          colors.text,
                      },
                    ]}
                  >
                    Verification code
                  </Text>

                  {renderInput(
                    "Enter 6-digit code",
                    verificationCode,
                    setVerificationCode,
                    {
                      keyboardType:
                        "number-pad",
                    }
                  )}

                  {renderPrimaryButton(
                    "Verify & continue",
                    verifyEmail
                  )}

                  <TouchableOpacity
                    onPress={
                      resendVerificationCode
                    }
                    style={
                      styles.backButton
                    }
                  >
                    <Text
                      style={[
                        styles.linkText,
                        {
                          color:
                            colors.primary,
                        },
                      ]}
                    >
                      Resend verification code
                    </Text>
                  </TouchableOpacity>

                  <TouchableOpacity
                    onPress={() => {
                      setAuthMode(
                        "login"
                      );

                      setVerificationCode(
                        ""
                      );

                      setMessage("");
                    }}
                    style={
                      styles.backButton
                    }
                  >
                    <Text
                      style={[
                        styles.secondaryLink,
                        {
                          color:
                            colors.textSecondary,
                        },
                      ]}
                    >
                      Back to sign in
                    </Text>
                  </TouchableOpacity>
                </>
              )}

              {authMode ===
                "reset" && (
                <>
                  <View
                    style={[
                      styles.emailBadge,
                      {
                        backgroundColor:
                          colors.surface2,

                        borderColor:
                          colors.border,
                      },
                    ]}
                  >
                    <Text
                      style={{
                        color:
                          colors.textSecondary,
                      }}
                    >
                      Resetting password for
                    </Text>

                    <Text
                      style={{
                        color:
                          colors.text,

                        fontWeight:
                          "700",

                        marginTop: 4,
                      }}
                    >
                      {email}
                    </Text>
                  </View>

                  <Text
                    style={[
                      styles.label,
                      {
                        color:
                          colors.text,
                      },
                    ]}
                  >
                    Reset code
                  </Text>

                  {renderInput(
                    "Enter reset code",
                    resetCode,
                    setResetCode,
                    {
                      keyboardType:
                        "number-pad",
                    }
                  )}

                  {!resetCodeVerified &&
                    renderPrimaryButton(
                      "Verify reset code",
                      verifyResetCode
                    )}

                  {resetCodeVerified && (
                    <>
                      <View
                        style={[
                          styles.successBox,
                          {
                            backgroundColor:
                              theme ===
                              "dark"
                                ? "#102A1A"
                                : "#ECFDF5",

                            borderColor:
                              colors.success,
                          },
                        ]}
                      >
                        <Text
                          style={{
                            color:
                              colors.success,

                            fontWeight:
                              "700",
                          }}
                        >
                          ✓ Code verified
                        </Text>
                      </View>

                      <Text
                        style={[
                          styles.label,
                          {
                            color:
                              colors.text,
                          },
                        ]}
                      >
                        New password
                      </Text>

                      {renderInput(
                        "Minimum 8 characters",
                        newPassword,
                        setNewPassword,
                        {
                          secure:
                            !showNewPassword,

                          right: (
                            <TouchableOpacity
                              onPress={() =>
                                setShowNewPassword(
                                  !showNewPassword
                                )
                              }
                              style={
                                styles.eyeButton
                              }
                            >
                              <Text
                                style={{
                                  color:
                                    colors.textSecondary,
                                }}
                              >
                                {showNewPassword
                                  ? "Hide"
                                  : "Show"}
                              </Text>
                            </TouchableOpacity>
                          ),
                        }
                      )}

                      {renderPrimaryButton(
                        "Update password",
                        resetPassword
                      )}
                    </>
                  )}

                  <TouchableOpacity
                    onPress={() => {
                      setAuthMode(
                        "login"
                      );

                      setResetCode(
                        ""
                      );

                      setNewPassword(
                        ""
                      );

                      setResetCodeVerified(
                        false
                      );
                    }}
                    style={
                      styles.backButton
                    }
                  >
                    <Text
                      style={[
                        styles.linkText,
                        {
                          color:
                            colors.primary,
                        },
                      ]}
                    >
                      Back to sign in
                    </Text>
                  </TouchableOpacity>
                </>
              )}

              {renderMessage()}
            </View>

            <Text
              style={[
                styles.footerText,
                {
                  color:
                    colors.textMuted,
                },
              ]}
            >
              ApplyAI • AI-powered career assistant
            </Text>
          </ScrollView>
        </KeyboardAvoidingView>
      </SafeAreaView>
    );
  }

  /*
   * ==========================================================
   * DASHBOARD HEADER
   * ==========================================================
   */

  function renderDashboardHeader() {
    return (
      <View
        style={[
          styles.dashboardTop,
          {
            backgroundColor:
              colors.surface,

            borderBottomColor:
              colors.border,
          },
        ]}
      >
        <View
          style={
            styles.brandRow
          }
        >
          <View
            style={[
              styles.logoSmall,
              {
                backgroundColor:
                  colors.primary,
              },
            ]}
          >
            <Text
              style={
                styles.logoText
              }
            >
              A
            </Text>
          </View>

          <View>
            <Text
              style={[
                styles.brandName,
                {
                  color:
                    colors.text,
                },
              ]}
            >
              ApplyAI
            </Text>

            <Text
              style={[
                styles.brandSubtitle,
                {
                  color:
                    colors.textSecondary,
                },
              ]}
            >
              Career workspace
            </Text>
          </View>
        </View>

        <View
          style={
            styles.headerActions
          }
        >
          {renderThemeButton()}

          <TouchableOpacity
            onPress={logout}
            activeOpacity={0.8}
            style={[
              styles.logoutButton,
              {
                backgroundColor:
                  colors.surface2,

                borderColor:
                  colors.border,
              },
            ]}
          >
            <Text
              style={{
                color:
                  colors.text,

                fontSize: 18,
              }}
            >
              ↪
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  /*
   * ==========================================================
   * WORKSPACE
   * ==========================================================
   */

  function renderWorkspace() {
    return (
      <>
        <View
          style={
            styles.welcomeSection
          }
        >
          <View
            style={{
              flex: 1,
            }}
          >
            <Text
              style={[
                styles.dashboardTitle,
                {
                  color:
                    colors.text,
                },
              ]}
            >
              Your career workspace
            </Text>

            <Text
              style={[
                styles.dashboardSubtitle,
                {
                  color:
                    colors.textSecondary,
                },
              ]}
            >
              Analyze jobs, tailor applications and move faster with AI.
            </Text>
          </View>
        </View>

        <View
          style={
            styles.statsGrid
          }
        >
          <View
            style={[
              styles.statCard,
              {
                backgroundColor:
                  colors.surface,

                borderColor:
                  colors.border,
              },
            ]}
          >
            <Text
              style={[
                styles.statNumber,
                {
                  color:
                    colors.primary,
                },
              ]}
            >
              {applications.length}
            </Text>

            <Text
              style={[
                styles.statLabel,
                {
                  color:
                    colors.textSecondary,
                },
              ]}
            >
              Applications
            </Text>
          </View>

          <View
            style={[
              styles.statCard,
              {
                backgroundColor:
                  colors.surface,

                borderColor:
                  colors.border,
              },
            ]}
          >
            <Text
              style={[
                styles.statNumber,
                {
                  color:
                    resumeName
                      ? colors.success
                      : colors.textMuted,
                },
              ]}
            >
              {resumeName
                ? "✓"
                : "—"}
            </Text>

            <Text
              style={[
                styles.statLabel,
                {
                  color:
                    colors.textSecondary,
                },
              ]}
            >
              Resume
            </Text>
          </View>
        </View>

        {/*
         * ====================================================
         * RESUME CARD
         * ====================================================
         */}

        <View
          style={[
            styles.card,
            {
              backgroundColor:
                colors.surface,

              borderColor:
                colors.border,
            },
          ]}
        >
          <View
            style={
              styles.cardHeader
            }
          >
            <View>
              <Text
                style={[
                  styles.cardTitle,
                  {
                    color:
                      colors.text,
                  },
                ]}
              >
                Your resume
              </Text>

              <Text
                style={[
                  styles.cardSubtitle,
                  {
                    color:
                      colors.textSecondary,
                  },
                ]}
              >
                Upload your latest resume for AI matching. We automatically pull your name, phone, email and LinkedIn from it.
              </Text>
            </View>

            <Text
              style={
                styles.cardEmoji
              }
            >
              📄
            </Text>
          </View>

          {resumeName ? (
            <View
              style={[
                styles.fileBox,
                {
                  backgroundColor:
                    colors.surface2,

                  borderColor:
                    colors.border,
                },
              ]}
            >
              <Text
                style={{
                  fontSize: 22,
                }}
              >
                ✓
              </Text>

              <View
                style={{
                  flex: 1,
                }}
              >
                <Text
                  style={[
                    styles.fileName,
                    {
                      color:
                        colors.text,
                    },
                  ]}
                  numberOfLines={1}
                >
                  {resumeName}
                </Text>

                <Text
                  style={{
                    color:
                      colors.success,

                    marginTop: 3,
                  }}
                >
                  Resume ready
                </Text>
              </View>
            </View>
          ) : (
            <View
              style={[
                styles.emptyUpload,
                {
                  borderColor:
                    colors.border,
                },
              ]}
            >
              <Text
                style={{
                  color:
                    colors.textSecondary,

                  textAlign:
                    "center",
                }}
              >
                No resume uploaded yet
              </Text>
            </View>
          )}

          {/*
           * ==================================================
           * UPLOAD BUTTON
           * ==================================================
           */}

          <TouchableOpacity
            onPress={pickResume}
            activeOpacity={0.85}
            style={[
              styles.secondaryButton,
              {
                borderColor:
                  colors.border,

                marginTop: 14,
              },
            ]}
          >
            <Text
              style={[
                styles.secondaryButtonText,
                {
                  color:
                    colors.text,
                },
              ]}
            >
              {resumeName
                ? "Replace resume"
                : "Upload resume"}
            </Text>
          </TouchableOpacity>

          {/*
           * ==================================================
           * FULL RESUME TEXT
           *
           * THIS IS THE NEW SECTION
           * ==================================================
           */}

          {!!resumeName && (
            <View
              style={[
                styles.resumeTextContainer,
                {
                  backgroundColor:
                    colors.surface2,

                  borderColor:
                    colors.border,
                },
              ]}
            >
              <View
                style={
                  styles.resumeTextHeader
                }
              >
                <View
                  style={{
                    flex: 1,
                  }}
                >
                  <Text
                    style={[
                      styles.resumeTextTitle,
                      {
                        color:
                          colors.text,
                      },
                    ]}
                  >
                    Full resume text
                  </Text>

                  <Text
                    style={[
                      styles.resumeTextSubtitle,
                      {
                        color:
                          colors.textSecondary,
                      },
                    ]}
                  >
                    The complete text extracted from your uploaded resume. You can edit it before AI analysis.
                  </Text>
                </View>

                <Text
                  style={{
                    fontSize: 22,
                  }}
                >
                  📝
                </Text>
              </View>

              <TextInput
                value={
                  resumeText
                }

                onChangeText={
                  setResumeText
                }

                placeholder="Your full resume text will appear here..."
                placeholderTextColor={
                  colors.textMuted
                }

                multiline

                textAlignVertical="top"

                scrollEnabled={true}

                style={[
                  styles.resumeTextInput,
                  {
                    backgroundColor:
                      colors.input,

                    borderColor:
                      colors.border,

                    color:
                      colors.text,
                  },
                ]}
              />

              {!resumeText.trim() && (
                <Text
                  style={[
                    styles.resumeTextWarning,
                    {
                      color:
                        colors.warning,
                    },
                  ]}
                >
                  Resume uploaded, but no readable text was extracted. Try refreshing from the server.
                </Text>
              )}

              <View
                style={
                  styles.resumeTextFooter
                }
              >
                <Text
                  style={{
                    color:
                      colors.textMuted,

                    fontSize: 11,
                  }}
                >
                  {resumeText
                    ? `${resumeText.length.toLocaleString()} characters`
                    : "No text extracted"}
                </Text>

                <TouchableOpacity
                  onPress={
                    refreshResumeTextFromServer
                  }
                  activeOpacity={0.8}
                  disabled={
                    loading
                  }
                >
                  <Text
                    style={{
                      color:
                        colors.primary,

                      fontSize: 12,

                      fontWeight:
                        "800",
                    }}
                  >
                    🔄 Refresh from server
                  </Text>
                </TouchableOpacity>
              </View>
            </View>
          )}

          {/*
           * ==================================================
           * CONTACT INFO
           * ==================================================
           */}

          {!!resumeName && (
            <View
              style={[
                styles.fileBox,
                {
                  backgroundColor:
                    colors.surface2,

                  borderColor:
                    colors.border,

                  marginTop: 14,

                  alignItems:
                    "flex-start",

                  flexDirection:
                    "column",

                  gap: 0,
                },
              ]}
            >
              <View
                style={{
                  flexDirection:
                    "row",

                  alignItems:
                    "center",

                  marginBottom: 10,
                }}
              >
                <Text
                  style={{
                    fontSize: 18,
                  }}
                >
                  🪪
                </Text>

                <Text
                  style={{
                    color:
                      colors.text,

                    fontWeight:
                      "750",

                    marginLeft: 8,
                  }}
                >
                  Your contact info
                </Text>
              </View>

              <Text
                style={{
                  color:
                    colors.textSecondary,

                  fontSize: 12,

                  lineHeight: 17,

                  marginBottom: 12,
                }}
              >
                Auto-filled from your resume where possible. Used in the header and signature of your AI cover letter.
              </Text>

              <View
                style={{
                  width: "100%",

                  gap: 10,
                }}
              >
                {renderInput(
                  "Full name",
                  profileName,
                  (value) => {
                    setProfileName(
                      value
                    );

                    saveProfile({
                      name: value,
                    });
                  }
                )}

                {renderInput(
                  "Phone number",
                  profilePhone,
                  (value) => {
                    setProfilePhone(
                      value
                    );

                    saveProfile({
                      phone: value,
                    });
                  },
                  {
                    keyboardType:
                      "phone-pad",
                  }
                )}

                {renderInput(
                  "Email address",
                  profileEmail,
                  (value) => {
                    setProfileEmail(
                      value
                    );

                    saveProfile({
                      email: value,
                    });
                  },
                  {
                    keyboardType:
                      "email-address",
                  }
                )}

                {renderInput(
                  "LinkedIn URL (optional)",
                  profileLinkedIn,
                  (value) => {
                    setProfileLinkedIn(
                      value
                    );

                    saveProfile({
                      linkedin:
                        value,
                    });
                  }
                )}

                {renderInput(
                  "Address (optional)",
                  profileAddress,
                  (value) => {
                    setProfileAddress(
                      value
                    );

                    saveProfile({
                      address:
                        value,
                    });
                  }
                )}
              </View>
            </View>
          )}
        </View>

        {/*
         * ====================================================
         * JOB ANALYSIS
         * ====================================================
         */}

        <View
          style={[
            styles.card,
            {
              backgroundColor:
                colors.surface,

              borderColor:
                colors.border,
            },
          ]}
        >
          <View
            style={
              styles.cardHeader
            }
          >
            <View
              style={{
                flex: 1,
              }}
            >
              <Text
                style={[
                  styles.cardTitle,
                  {
                    color:
                      colors.text,
                  },
                ]}
              >
                Analyze a job
              </Text>

              <Text
                style={[
                  styles.cardSubtitle,
                  {
                    color:
                      colors.textSecondary,
                  },
                ]}
              >
                Paste a job description and let ApplyAI analyze the opportunity.
              </Text>
            </View>

            <Text
              style={
                styles.cardEmoji
              }
            >
              ✨
            </Text>
          </View>

          <Text
            style={[
              styles.label,
              {
                color:
                  colors.text,
              },
            ]}
          >
            Job URL
          </Text>

          {renderInput(
            "https://company.com/jobs/...",
            jobUrl,
            setJobUrl
          )}

          <Text
            style={[
              styles.label,
              {
                color:
                  colors.text,
              },
            ]}
          >
            Job description
          </Text>

          {renderInput(
            "Paste the complete job description here...",
            jobDescription,
            setJobDescription,
            {
              multiline:
                true,
            }
          )}

          {renderPrimaryButton(
            "Analyze job",
            analyzeJob
          )}
        </View>

        {/*
         * ====================================================
         * ANALYSIS RESULT
         * ====================================================
         */}

        {analysis && (
          <View
            style={[
              styles.card,
              {
                backgroundColor:
                  colors.surface,

                borderColor:
                  colors.border,
              },
            ]}
          >
            <View
              style={
                styles.cardHeader
              }
            >
              <View
                style={{
                  flex: 1,
                }}
              >
                <Text
                  style={[
                    styles.cardTitle,
                    {
                      color:
                        colors.text,
                    },
                  ]}
                >
                  AI job analysis
                </Text>

                <Text
                  style={[
                    styles.cardSubtitle,
                    {
                      color:
                        colors.textSecondary,
                    },
                  ]}
                >
                  AI-generated assessment based on your resume and job description.
                </Text>
              </View>

              <View
                style={[
                  styles.scoreCircle,
                  {
                    backgroundColor:
                      colors.primarySoft,
                  },
                ]}
              >
                <Text
                  style={{
                    color:
                      colors.primary,

                    fontWeight:
                      "800",
                  }}
                >
                  {Math.round(
                    analysis.match_score ??
                      analysis.score ??
                      0
                  )}
                </Text>
              </View>
            </View>

            {!!analysis.summary && (
              <View
                style={
                  styles.analysisSection
                }
              >
                <Text
                  style={[
                    styles.analysisHeading,
                    {
                      color:
                        colors.text,
                    },
                  ]}
                >
                  Summary
                </Text>

                <Text
                  style={[
                    styles.bodyText,
                    {
                      color:
                        colors.textSecondary,
                    },
                  ]}
                >
                  {analysis.summary}
                </Text>
              </View>
            )}

            {!!analysis.strengths
              ?.length && (
              <View
                style={
                  styles.analysisSection
                }
              >
                <Text
                  style={[
                    styles.analysisHeading,
                    {
                      color:
                        colors.text,
                    },
                  ]}
                >
                  Strengths
                </Text>

                {analysis.strengths.map(
                  (
                    item,
                    index
                  ) => (
                    <Text
                      key={
                        index
                      }
                      style={[
                        styles.listItem,
                        {
                          color:
                            colors.textSecondary,
                        },
                      ]}
                    >
                      • {item}
                    </Text>
                  )
                )}
              </View>
            )}

            {!!analysis.missing_skills
              ?.length && (
              <View
                style={
                  styles.analysisSection
                }
              >
                <Text
                  style={[
                    styles.analysisHeading,
                    {
                      color:
                        colors.text,
                    },
                  ]}
                >
                  Missing skills
                </Text>

                {analysis.missing_skills.map(
                  (
                    item,
                    index
                  ) => (
                    <Text
                      key={
                        index
                      }
                      style={[
                        styles.listItem,
                        {
                          color:
                            colors.textSecondary,
                        },
                      ]}
                    >
                      • {item}
                    </Text>
                  )
                )}
              </View>
            )}

            <View
              style={
                styles.actionRow
              }
            >
              <TouchableOpacity
                onPress={
                  generateCoverLetter
                }
                activeOpacity={
                  0.85
                }
                style={[
                  styles.actionButton,
                  {
                    backgroundColor:
                      colors.primary,
                  },
                ]}
              >
                <Text
                  style={
                    styles.actionButtonText
                  }
                >
                  Generate cover letter
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={
                  saveApplication
                }
                activeOpacity={
                  0.85
                }
                style={[
                  styles.actionButton,
                  {
                    backgroundColor:
                      colors.surface2,

                    borderWidth: 1,

                    borderColor:
                      colors.border,
                  },
                ]}
              >
                <Text
                  style={[
                    styles.actionButtonText,
                    {
                      color:
                        colors.text,
                    },
                  ]}
                >
                  Save application
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        )}

        {/*
         * ====================================================
         * COVER LETTER
         * ====================================================
         */}

        {!!coverLetter && (
          <View
            style={[
              styles.card,
              {
                backgroundColor:
                  colors.surface,

                borderColor:
                  colors.border,
              },
            ]}
          >
            <Text
              style={[
                styles.cardTitle,
                {
                  color:
                    colors.text,
                },
              ]}
            >
              AI cover letter
            </Text>

            <Text
              style={[
                styles.coverLetter,
                {
                  color:
                    colors.textSecondary,
                },
              ]}
            >
              {coverLetter}
            </Text>
          </View>
        )}

        {renderMessage()}
      </>
    );
  }

  /*
   * ==========================================================
   * APPLICATIONS
   * ==========================================================
   */

  function renderApplications() {
    return (
      <>
        <View
          style={
            styles.welcomeSection
          }
        >
          <View>
            <Text
              style={[
                styles.dashboardTitle,
                {
                  color:
                    colors.text,
                },
              ]}
            >
              Applications
            </Text>

            <Text
              style={[
                styles.dashboardSubtitle,
                {
                  color:
                    colors.textSecondary,
                },
              ]}
            >
              Keep track of your saved opportunities.
            </Text>
          </View>

          <TouchableOpacity
            onPress={
              loadApplications
            }
            activeOpacity={0.8}
            style={[
              styles.refreshButton,
              {
                backgroundColor:
                  colors.surface,

                borderColor:
                  colors.border,
              },
            ]}
          >
            <Text
              style={{
                color:
                  colors.text,

                fontSize: 18,
              }}
            >
              ↻
            </Text>
          </TouchableOpacity>
        </View>

        {applications.length ===
        0 ? (
          <View
            style={[
              styles.emptyCard,
              {
                backgroundColor:
                  colors.surface,

                borderColor:
                  colors.border,
              },
            ]}
          >
            <Text
              style={{
                fontSize: 42,
              }}
            >
              📋
            </Text>

            <Text
              style={[
                styles.emptyTitle,
                {
                  color:
                    colors.text,
                },
              ]}
            >
              No applications yet
            </Text>

            <Text
              style={[
                styles.emptyText,
                {
                  color:
                    colors.textSecondary,
                },
              ]}
            >
              Analyze a job from your workspace and save it here.
            </Text>
          </View>
        ) : (
          applications.map(
            (
              application,
              index
            ) => (
              <TouchableOpacity
                key={
                  application.id ??
                  index
                }
                activeOpacity={
                  0.85
                }
                onPress={() =>
                  setSelectedApplication(
                    application
                  )
                }
                style={[
                  styles.applicationCard,
                  {
                    backgroundColor:
                      colors.surface,

                    borderColor:
                      colors.border,
                  },
                ]}
              >
                <View
                  style={
                    styles.applicationTop
                  }
                >
                  <View
                    style={{
                      flex: 1,
                    }}
                  >
                    <Text
                      style={[
                        styles.applicationTitle,
                        {
                          color:
                            colors.text,
                        },
                      ]}
                      numberOfLines={
                        2
                      }
                    >
                      {application.job_title ||
                        "Job Application"}
                    </Text>

                    <Text
                      style={[
                        styles.applicationCompany,
                        {
                          color:
                            colors.textSecondary,
                        },
                      ]}
                    >
                      {application.company ||
                        "Company not specified"}
                    </Text>
                  </View>

                  <View
                    style={[
                      styles.matchBadge,
                      {
                        backgroundColor:
                          colors.primarySoft,
                      },
                    ]}
                  >
                    <Text
                      style={{
                        color:
                          colors.primary,

                        fontWeight:
                          "800",
                      }}
                    >
                      {Math.round(
                        application.match_score ??
                          0
                      )}
                    </Text>
                  </View>
                </View>

                <View
                  style={
                    styles.applicationBottom
                  }
                >
                  <Text
                    style={{
                      color:
                        colors.textMuted,
                    }}
                  >
                    {application.status ||
                      "SAVED"}
                  </Text>

                  <Text
                    style={{
                      color:
                        colors.primary,

                      fontWeight:
                        "700",
                    }}
                  >
                    View →
                  </Text>
                </View>
              </TouchableOpacity>
            )
          )
        )}

        {selectedApplication && (
          <View
            style={[
              styles.modalCard,
              {
                backgroundColor:
                  colors.surface,

                borderColor:
                  colors.border,
              },
            ]}
          >
            <View
              style={
                styles.cardHeader
              }
            >
              <Text
                style={[
                  styles.cardTitle,
                  {
                    color:
                      colors.text,
                  },
                ]}
              >
                Application details
              </Text>

              <TouchableOpacity
                onPress={() =>
                  setSelectedApplication(
                    null
                  )
                }
              >
                <Text
                  style={{
                    color:
                      colors.textSecondary,

                    fontSize: 20,
                  }}
                >
                  ×
                </Text>
              </TouchableOpacity>
            </View>

            <Text
              style={[
                styles.detailTitle,
                {
                  color:
                    colors.text,
                },
              ]}
            >
              {selectedApplication.job_title ||
                "Job Application"}
            </Text>

            <Text
              style={[
                styles.detailCompany,
                {
                  color:
                    colors.textSecondary,
                },
              ]}
            >
              {selectedApplication.company ||
                "Company not specified"}
            </Text>

            <View
              style={[
                styles.detailRow,
                {
                  borderBottomColor:
                    colors.border,
                },
              ]}
            >
              <Text
                style={{
                  color:
                    colors.textSecondary,
                }}
              >
                Match score
              </Text>

              <Text
                style={{
                  color:
                    colors.primary,

                  fontWeight:
                    "800",
                }}
              >
                {Math.round(
                  selectedApplication.match_score ??
                    0
                )}
              </Text>
            </View>

            <View
              style={[
                styles.detailRow,
                {
                  borderBottomColor:
                    colors.border,
                },
              ]}
            >
              <Text
                style={{
                  color:
                    colors.textSecondary,
                }}
              >
                Status
              </Text>

              <Text
                style={{
                  color:
                    colors.text,

                  fontWeight:
                    "700",
                }}
              >
                {selectedApplication.status ||
                  "SAVED"}
              </Text>
            </View>

            {!!selectedApplication.cover_letter && (
              <View
                style={{
                  marginTop: 18,
                }}
              >
                <Text
                  style={[
                    styles.analysisHeading,
                    {
                      color:
                        colors.text,
                    },
                  ]}
                >
                  Cover letter
                </Text>

                <Text
                  style={[
                    styles.bodyText,
                    {
                      color:
                        colors.textSecondary,
                    },
                  ]}
                >
                  {
                    selectedApplication.cover_letter
                  }
                </Text>
              </View>
            )}
          </View>
        )}
      </>
    );
  }

  /*
   * ==========================================================
   * DASHBOARD
   * ==========================================================
   */

  function renderDashboard() {
    return (
      <SafeAreaView
        style={[
          styles.safe,
          {
            backgroundColor:
              colors.background,
          },
        ]}
      >
        <StatusBar
          barStyle={
            theme === "dark"
              ? "light-content"
              : "dark-content"
          }

          backgroundColor={
            colors.surface
          }
        />

        {renderDashboardHeader()}

        <ScrollView
          showsVerticalScrollIndicator={
            true
          }

          persistentScrollbar={
            true
          }

          contentContainerStyle={
            styles.dashboardContent
          }
        >
          {activeTab ===
          "workspace"
            ? renderWorkspace()
            : renderApplications()}
        </ScrollView>

        <View
          style={[
            styles.bottomNav,
            {
              backgroundColor:
                colors.surface,

              borderTopColor:
                colors.border,
            },
          ]}
        >
          <TouchableOpacity
            onPress={() =>
              setActiveTab(
                "workspace"
              )
            }
            activeOpacity={0.8}
            style={
              styles.navItem
            }
          >
            <Text
              style={{
                fontSize: 20,
              }}
            >
              ⌂
            </Text>

            <Text
              style={[
                styles.navLabel,
                {
                  color:
                    activeTab ===
                    "workspace"
                      ? colors.primary
                      : colors.textMuted,
                },
              ]}
            >
              Workspace
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() =>
              setActiveTab(
                "applications"
              )
            }
            activeOpacity={0.8}
            style={
              styles.navItem
            }
          >
            <Text
              style={{
                fontSize: 20,
              }}
            >
              ▣
            </Text>

            <Text
              style={[
                styles.navLabel,
                {
                  color:
                    activeTab ===
                    "applications"
                      ? colors.primary
                      : colors.textMuted,
                },
              ]}
            >
              Applications
            </Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  /*
   * ==========================================================
   * SPLASH
   * ==========================================================
   */

  if (initializing) {
    return (
      <SafeAreaView
        style={[
          styles.splash,
          {
            backgroundColor:
              colors.background,
          },
        ]}
      >
        <StatusBar
          barStyle={
            theme === "dark"
              ? "light-content"
              : "dark-content"
          }

          backgroundColor={
            colors.background
          }
        />

        <View
          style={[
            styles.splashLogo,
            {
              backgroundColor:
                colors.primary,
            },
          ]}
        >
          <Text
            style={
              styles.splashLogoText
            }
          >
            A
          </Text>
        </View>

        <Text
          style={[
            styles.splashTitle,
            {
              color:
                colors.text,
            },
          ]}
        >
          ApplyAI
        </Text>

        <Text
          style={[
            styles.splashSubtitle,
            {
              color:
                colors.textSecondary,
            },
          ]}
        >
          AI-powered career assistant
        </Text>

        <ActivityIndicator
          color={
            colors.primary
          }
          size="small"
          style={{
            marginTop: 30,
          }}
        />
      </SafeAreaView>
    );
  }

  /*
   * ==========================================================
   * ROUTING
   * ==========================================================
   */

  if (!token) {
    return renderAuth();
  }

  return renderDashboard();
}

/*
 * ============================================================
 * STYLES
 * ============================================================
 */

const styles = StyleSheet.create({
  safe: {
    flex: 1,
  },

  splash: {
    flex: 1,
    alignItems: "center",
    justifyContent:
      "center",
  },

  splashLogo: {
  width: 92,
  height: 92,
  borderRadius: 28,
  alignItems: "center",
  justifyContent: "center",
  // Keep native elevation; avoid deprecated shadow props on web.
  elevation: 10,
},

  splashLogoText: {
    color: "#FFFFFF",
    fontSize: 52,
    fontWeight: "900",
  },

  splashTitle: {
    fontSize: 34,
    fontWeight: "900",
    marginTop: 22,
    letterSpacing: -1,
  },

  splashSubtitle: {
    fontSize: 14,
    marginTop: 8,
  },

  header: {
    height: 72,
    paddingHorizontal: 18,
    flexDirection: "row",
    alignItems: "center",
    justifyContent:
      "space-between",
    borderBottomWidth: 1,
  },

  dashboardTop: {
    minHeight: 72,
    paddingHorizontal: 18,
    flexDirection: "row",
    alignItems: "center",
    justifyContent:
      "space-between",
    borderBottomWidth: 1,
  },

  brandRow: {
    flexDirection: "row",
    alignItems: "center",
  },

  logoSmall: {
    width: 42,
    height: 42,
    borderRadius: 13,
    alignItems: "center",
    justifyContent:
      "center",
    marginRight: 11,
  },

  logoText: {
    color: "#FFFFFF",
    fontSize: 23,
    fontWeight: "900",
  },

  brandName: {
    fontSize: 18,
    fontWeight: "900",
  },

  brandSubtitle: {
    fontSize: 11,
    marginTop: 1,
  },

  headerActions: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },

  themeButton: {
    width: 42,
    height: 42,
    borderRadius: 14,
    alignItems: "center",
    justifyContent:
      "center",
    borderWidth: 1,
  },

  themeIcon: {
    fontSize: 18,
  },

  logoutButton: {
    width: 42,
    height: 42,
    borderRadius: 14,
    alignItems: "center",
    justifyContent:
      "center",
    borderWidth: 1,
  },

  authScroll: {
    flexGrow: 1,
    justifyContent:
      "center",
    padding: 20,
    paddingTop: 32,
    paddingBottom: 40,
  },

  authCard: {
    width: "100%",
    maxWidth: 480,
    alignSelf: "center",
    borderWidth: 1,
    borderRadius: 28,
    padding: 24,
  },

  heroIcon: {
    width: 58,
    height: 58,
    borderRadius: 18,
    alignItems: "center",
    justifyContent:
      "center",
    marginBottom: 20,
  },

  heroIconText: {
    color: "#6366F1",
    fontSize: 29,
    fontWeight: "900",
  },

  authTitle: {
    fontSize: 29,
    fontWeight: "900",
    letterSpacing: -0.7,
  },

  authSubtitle: {
    fontSize: 14,
    lineHeight: 21,
    marginTop: 8,
    marginBottom: 25,
  },

  label: {
    fontSize: 13,
    fontWeight: "700",
    marginBottom: 8,
    marginTop: 12,
  },

  inputWrapper: {
    minHeight: 54,
    borderRadius: 15,
    borderWidth: 1,
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 15,
  },

  input: {
    flex: 1,
    fontSize: 15,
    paddingVertical: 14,
  },

  eyeButton: {
    paddingLeft: 10,
    paddingVertical: 10,
  },

  primaryButton: {
    minHeight: 54,
    borderRadius: 15,
    alignItems: "center",
    justifyContent:
      "center",
    marginTop: 20,
  },

  primaryButtonText: {
    color: "#FFFFFF",
    fontSize: 15,
    fontWeight: "800",
  },

  secondaryButton: {
    minHeight: 52,
    borderRadius: 15,
    borderWidth: 1,
    alignItems: "center",
    justifyContent:
      "center",
  },

  secondaryButtonText: {
    fontSize: 14,
    fontWeight: "750",
  },

  forgotButton: {
    alignSelf:
      "flex-end",
    marginTop: 10,
  },

  linkText: {
    fontSize: 13,
    fontWeight: "700",
  },

  secondaryLink: {
    fontSize: 13,
    fontWeight: "600",
  },

  backButton: {
    alignItems: "center",
    marginTop: 18,
  },

  dividerRow: {
    flexDirection: "row",
    alignItems: "center",
    marginVertical: 22,
  },

  divider: {
    height: 1,
    flex: 1,
  },

  dividerText: {
    fontSize: 11,
    fontWeight: "700",
    marginHorizontal: 12,
  },

  messageBox: {
    borderRadius: 14,
    borderWidth: 1,
    padding: 13,
    marginTop: 18,
  },

  messageText: {
    fontSize: 13,
    lineHeight: 19,
    fontWeight: "600",
  },

  emailBadge: {
    borderRadius: 15,
    borderWidth: 1,
    padding: 14,
    marginBottom: 6,
  },

  successBox: {
    borderRadius: 14,
    borderWidth: 1,
    padding: 13,
    marginTop: 14,
  },

  footerText: {
    textAlign: "center",
    fontSize: 11,
    marginTop: 20,
  },

  dashboardContent: {
    padding: 18,
    paddingBottom: 100,
  },

  welcomeSection: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 18,
  },

  dashboardTitle: {
    fontSize: 26,
    fontWeight: "900",
    letterSpacing: -0.5,
  },

  dashboardSubtitle: {
    fontSize: 13,
    lineHeight: 19,
    marginTop: 5,
    maxWidth: 600,
  },

  statsGrid: {
    flexDirection: "row",
    gap: 12,
    marginBottom: 14,
  },

  statCard: {
    flex: 1,
    minHeight: 100,
    borderRadius: 20,
    borderWidth: 1,
    padding: 17,
    justifyContent:
      "center",
  },

  statNumber: {
    fontSize: 27,
    fontWeight: "900",
  },

  statLabel: {
    fontSize: 12,
    marginTop: 4,
  },

  card: {
    borderWidth: 1,
    borderRadius: 22,
    padding: 18,
    marginBottom: 14,
  },

  cardHeader: {
    flexDirection: "row",
    justifyContent:
      "space-between",
    alignItems:
      "flex-start",
    marginBottom: 14,
  },

  cardTitle: {
    fontSize: 18,
    fontWeight: "850",
  },

  cardSubtitle: {
    fontSize: 12,
    lineHeight: 18,
    marginTop: 5,
    maxWidth: 500,
  },

  cardEmoji: {
    fontSize: 25,
    marginLeft: 12,
  },

  fileBox: {
    borderRadius: 15,
    borderWidth: 1,
    padding: 14,
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },

  fileName: {
    fontSize: 14,
    fontWeight: "750",
  },

  emptyUpload: {
    minHeight: 90,
    borderRadius: 15,
    borderWidth: 1,
    borderStyle: "dashed",
    alignItems: "center",
    justifyContent:
      "center",
  },

  /*
   * ----------------------------------------------------------
   * NEW RESUME TEXT STYLES
   * ----------------------------------------------------------
   */

  resumeTextContainer: {
    borderRadius: 18,
    borderWidth: 1,
    padding: 15,
    marginTop: 14,
  },

  resumeTextHeader: {
    flexDirection: "row",
    alignItems:
      "flex-start",
    marginBottom: 12,
  },

  resumeTextTitle: {
    fontSize: 15,
    fontWeight: "800",
  },

  resumeTextSubtitle: {
    fontSize: 12,
    lineHeight: 18,
    marginTop: 4,
  },

  resumeTextInput: {
    width: "100%",
    minHeight: 320,
    maxHeight: 600,
    borderRadius: 14,
    borderWidth: 1,
    paddingHorizontal: 14,
    paddingVertical: 13,
    fontSize: 13,
    lineHeight: 20,
  },

  resumeTextWarning: {
    fontSize: 12,
    lineHeight: 18,
    marginTop: 10,
  },

  resumeTextFooter: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent:
      "space-between",
    marginTop: 10,
    gap: 10,
  },

  /*
   * ----------------------------------------------------------
   * ANALYSIS
   * ----------------------------------------------------------
   */

  scoreCircle: {
    width: 52,
    height: 52,
    borderRadius: 26,
    alignItems: "center",
    justifyContent:
      "center",
    marginLeft: 12,
  },

  analysisSection: {
    marginTop: 15,
  },

  analysisHeading: {
    fontSize: 14,
    fontWeight: "800",
    marginBottom: 7,
  },

  bodyText: {
    fontSize: 13,
    lineHeight: 21,
  },

  listItem: {
    fontSize: 13,
    lineHeight: 21,
    marginBottom: 3,
  },

  actionRow: {
    gap: 10,
    marginTop: 20,
  },

  actionButton: {
    minHeight: 50,
    borderRadius: 14,
    alignItems: "center",
    justifyContent:
      "center",
    paddingHorizontal: 16,
  },

  actionButtonText: {
    color: "#FFFFFF",
    fontSize: 13,
    fontWeight: "800",
  },

  coverLetter: {
    fontSize: 13,
    lineHeight: 22,
    marginTop: 12,
  },

  /*
   * ----------------------------------------------------------
   * BOTTOM NAV
   * ----------------------------------------------------------
   */

  bottomNav: {
    height: 72,
    borderTopWidth: 1,
    flexDirection: "row",
    justifyContent:
      "space-around",
    alignItems: "center",
    paddingBottom:
      Platform.OS === "ios"
        ? 8
        : 0,
  },

  navItem: {
    alignItems: "center",
    justifyContent:
      "center",
    minWidth: 110,
  },

  navLabel: {
    fontSize: 11,
    fontWeight: "700",
    marginTop: 4,
  },

  /*
   * ----------------------------------------------------------
   * APPLICATIONS
   * ----------------------------------------------------------
   */

  refreshButton: {
    width: 44,
    height: 44,
    borderRadius: 14,
    borderWidth: 1,
    alignItems: "center",
    justifyContent:
      "center",
  },

  emptyCard: {
    minHeight: 260,
    borderRadius: 22,
    borderWidth: 1,
    alignItems: "center",
    justifyContent:
      "center",
    padding: 28,
  },

  emptyTitle: {
    fontSize: 19,
    fontWeight: "850",
    marginTop: 15,
  },

  emptyText: {
    fontSize: 13,
    lineHeight: 20,
    textAlign: "center",
    marginTop: 8,
    maxWidth: 330,
  },

  applicationCard: {
    borderRadius: 20,
    borderWidth: 1,
    padding: 17,
    marginBottom: 12,
  },

  applicationTop: {
    flexDirection: "row",
    alignItems:
      "flex-start",
  },

  applicationTitle: {
    fontSize: 16,
    fontWeight: "800",
    lineHeight: 21,
  },

  applicationCompany: {
    fontSize: 12,
    marginTop: 5,
  },

  matchBadge: {
    minWidth: 48,
    height: 40,
    borderRadius: 12,
    alignItems: "center",
    justifyContent:
      "center",
    marginLeft: 10,
  },

  applicationBottom: {
    flexDirection: "row",
    justifyContent:
      "space-between",
    alignItems: "center",
    marginTop: 17,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor:
      "rgba(148,163,184,0.15)",
  },

  modalCard: {
    borderRadius: 22,
    borderWidth: 1,
    padding: 18,
    marginTop: 8,
  },

  detailTitle: {
    fontSize: 20,
    fontWeight: "850",
  },

  detailCompany: {
    fontSize: 13,
    marginTop: 5,
    marginBottom: 15,
  },

  detailRow: {
    minHeight: 48,
    borderBottomWidth: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent:
      "space-between",
  },
});